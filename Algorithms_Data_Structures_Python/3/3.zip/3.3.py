#program wypisujacy liczby z przedzialu 0-30 z wyjatkiem liczb podzielnych przez 3

for i in range(30):
	if i%3:
		print i,